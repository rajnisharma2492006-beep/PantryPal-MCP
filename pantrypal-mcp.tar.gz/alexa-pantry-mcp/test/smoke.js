// Protocol smoke test: starts the server, runs an MCP session over Streamable HTTP.
import { spawn } from "node:child_process";
import assert from "node:assert/strict";
import { fileURLToPath } from "node:url";
import path from "node:path";

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const PORT = 3917;
const URL_ = `http://localhost:${PORT}/mcp`;
const srv = spawn("node", ["server.js"], { cwd: root, env: { ...process.env, PORT: String(PORT) }, stdio: "ignore" });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let n = 0, sid, ver = "2025-11-25";

async function rpc(method, params, { notify = false, extra = {} } = {}) {
  const body = { jsonrpc: "2.0", method, params };
  if (!notify) body.id = ++n;
  const headers = { "Content-Type": "application/json", Accept: "application/json, text/event-stream", ...extra };
  if (sid) { headers["Mcp-Session-Id"] = sid; headers["MCP-Protocol-Version"] = ver; }
  const res = await fetch(URL_, { method: "POST", headers, body: JSON.stringify(body) });
  const text = await res.text();
  let json = null;
  try { json = text ? JSON.parse(text) : null; } catch { /* non-JSON error body */ }
  return { res, json, text };
}
const call = async (name, args) => (await rpc("tools/call", { name, arguments: args })).json;

try {
  for (let i = 0; i < 30; i++) { try { await fetch(`http://localhost:${PORT}/health`); break; } catch { await sleep(100); } }

  let r = await rpc("initialize", { protocolVersion: "2025-11-25", capabilities: {}, clientInfo: { name: "smoke", version: "0" } });
  assert.equal(r.json.result.protocolVersion, "2025-11-25");
  sid = r.res.headers.get("mcp-session-id");
  assert.ok(sid, "session id issued");
  console.log("✓ initialize + session id");

  r = await rpc("notifications/initialized", undefined, { notify: true });
  assert.equal(r.res.status, 202);
  console.log("✓ notification → 202");

  r = await rpc("tools/list");
  const names = r.json.result.tools.map((t) => t.name);
  assert.ok(names.includes("suggest_recipes") && names.length >= 7);
  console.log(`✓ tools/list (${names.length} tools)`);

  r = await call("add_pantry_item", { name: "Paneer", quantity: 2, unit: "packs", expires_in_days: 2 });
  assert.equal(r.result.structuredContent.item.name, "paneer");
  console.log("✓ add_pantry_item");

  r = await call("suggest_recipes", {});
  assert.ok(r.result.structuredContent.recipes.length > 0);
  console.log("✓ suggest_recipes →", r.result.content[0].text);

  r = await call("add_to_shopping_list", { recipe: "Tomato Pasta" });
  assert.ok(r.result.structuredContent.added.includes("pasta"));
  console.log("✓ add_to_shopping_list (recipe)");

  r = await call("remove_pantry_item", { name: "unicorn" });
  assert.equal(r.result.isError, true);
  console.log("✓ tool execution error → isError");

  r = await call("add_pantry_item", {});
  assert.equal(r.error.code, -32602);
  console.log("✓ invalid params → -32602");

  r = await rpc("nope");
  assert.equal(r.json.error.code, -32601);
  console.log("✓ unknown method → -32601");

  r = await rpc("ping", undefined, { extra: { Origin: "https://evil.example" } });
  assert.equal(r.res.status, 403);
  console.log("✓ bad Origin rejected (DNS-rebinding protection)");

  const g = await fetch(URL_, { method: "GET" });
  assert.equal(g.status, 405);
  console.log("✓ GET /mcp → 405");

  console.log("\nAll checks passed.");
} catch (e) {
  console.error("FAILED:", e.message);
  process.exitCode = 1;
} finally {
  srv.kill();
}
