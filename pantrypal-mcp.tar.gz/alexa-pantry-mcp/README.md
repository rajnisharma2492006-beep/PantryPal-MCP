# PantryPal — a self-hosted MCP server for Alexa+

> "Alexa, what can I cook tonight?" — PantryPal knows what's in your kitchen, what's about to expire, and what to add to the shopping list.

PantryPal is a **self-hosted MCP server** (spec **2025-11-25**, **Streamable HTTP**) that gives Alexa+ a kitchen-management capability. It ships with a **simulated Alexa+ web client** (voice + text) so you can see the whole thing working without an Echo device.

- **Zero dependencies.** Pure Node.js (≥ 18). `node server.js` and you're running.
- **Real MCP wire protocol**, visible live in the demo's "wire trace" panel.

## Quick start

```bash
git clone <your-repo-url> && cd alexa-pantry-mcp
npm start                 # → http://localhost:3000   (MCP endpoint: /mcp)
npm test                  # protocol smoke test (11 checks)
```

Open http://localhost:3000 and tap a suggestion chip, type, or use the 🎤 button (Chrome/Edge).

## What it does

| Tool | Purpose |
|---|---|
| `add_pantry_item` | Add/increase an ingredient (name, quantity, unit, expiry) |
| `list_pantry` | Everything in the pantry with days-left |
| `remove_pantry_item` | Use up or remove an ingredient |
| `check_expiring` | Items expiring within N days |
| `suggest_recipes` | Recipes from what you have, fewest missing ingredients first, prioritising expiring items |
| `add_to_shopping_list` | Add an item, or all missing ingredients for a recipe |
| `get_shopping_list` | Read the list back |

The tools carry MCP `annotations` (`readOnlyHint`, `destructiveHint`, `idempotentHint`) so an agent can tell safe reads from destructive writes.

## How it works

```
 You (voice/text)
      │
      ▼
 Simulated Alexa+  ──(intent routing)──►  MCP client (browser JS)
                                               │  JSON-RPC 2.0
                                               │  POST /mcp  (Streamable HTTP)
                                               ▼
                                   PantryPal MCP server (server.js)
                                     initialize → tools/list → tools/call
                                               │
                                               ▼
                                     data/state.json (pantry + list)
```

1. **Handshake:** client sends `initialize` (protocol `2025-11-25`); server negotiates the version, returns capabilities and an `Mcp-Session-Id`. Client sends `notifications/initialized` (server replies `202`).
2. **Discovery:** `tools/list` returns each tool's name, description and JSON Schema.
3. **Invocation:** `tools/call` validates arguments, runs the tool, and returns human-readable `content` (what Alexa speaks) plus `structuredContent` (machine-readable data the UI renders).
4. **Errors:** protocol errors use JSON-RPC codes (`-32602` bad params, `-32601` unknown method); tool-level failures return `isError: true` so the model can recover.

### Protocol details implemented
- Streamable HTTP single endpoint `/mcp` (POST; GET returns `405` since there's no server-initiated stream; DELETE ends a session)
- Version negotiation (`2025-11-25`, `2025-06-18`, `2025-03-26`), `MCP-Protocol-Version` and `Mcp-Session-Id` headers
- **`Origin` validation** to block DNS-rebinding attacks (set `ALLOWED_ORIGINS=https://a.com,https://b.com` for extra origins)
- Notifications → `202 Accepted`; unknown session → `404`

## Honest scope notes
- The in-browser "Alexa+" uses a small regex intent router as a stand-in for Alexa+'s LLM. The MCP server is the real, reusable part: point any MCP client at `http://<host>:3000/mcp`.
- Auth is not implemented (demo data only). For production, add OAuth 2.1 per the MCP authorization spec and serve over HTTPS.
- Tests were run against Node 22. The server is hand-rolled to stay dependency-free; swapping in the official `@modelcontextprotocol/sdk` is a straightforward follow-up (the `TOOLS` array maps 1:1 to `registerTool`).

## Roadmap — from hackathon demo to real Alexa+ skill

**Phase 1 — Hackathon MVP (this repo)** ✅
MCP server, 7 tools, spec-compliant transport, simulated Alexa+ client, smoke tests.

**Phase 2 — Make it real (1–2 weeks)**
- Deploy on a public HTTPS host (Render / Fly.io / AWS) and register it as an Alexa+ MCP integration
- OAuth 2.1 account linking so each household has its own pantry
- Swap JSON file for SQLite/DynamoDB
- Swap the regex router for an LLM client that does real tool selection

**Phase 3 — Delight (2–4 weeks)**
- Barcode / receipt scan to bulk-add groceries
- Expiry nudges ("your milk expires tomorrow") using MCP notifications over SSE
- Dietary preferences, serving sizes, and a bigger/real recipe source
- Auto-reorder via grocery partners

## Demo video script (≈ 2 minutes)
1. **Problem (15s):** food waste + "what's for dinner?" fatigue.
2. **Show the wire (20s):** open the page; point at the trace panel — `initialize` → `tools/list`.
3. **Voice moments (60s):** "What's expiring soon?" → "What can I cook tonight?" → "I bought 2 packs of paneer" → ask again and watch the recipe ranking change → "Add the missing ingredients for Tomato Pasta" → "What's on my shopping list?"
4. **Tech close (25s):** zero-dependency, spec 2025-11-25, Origin validation, `npm test` passing, roadmap.

## Project description (paste into Devpost)

**PantryPal** is a self-hosted MCP server that lets Alexa+ manage a household's pantry and shopping list. Users say things like "what can I cook tonight?" or "I bought two packs of paneer", and Alexa+ calls PantryPal's tools over MCP (spec 2025-11-25, Streamable HTTP). The server tracks ingredients and expiry dates, ranks recipes by how few ingredients are missing (prioritising items about to expire), and builds shopping lists from a chosen recipe's gaps. It reduces food waste and removes the nightly "what's for dinner" friction. A simulated Alexa+ web client with voice input and a live MCP wire-trace demonstrates the full handshake, tool discovery and tool calls. Built in dependency-free Node.js with a protocol test suite.

## License
MIT — see [LICENSE](LICENSE).
