// PantryPal MCP server — Streamable HTTP transport, zero dependencies.
// Implements MCP (spec 2025-11-25, backward compatible with 2025-06-18 / 2025-03-26)
// Endpoint: POST /mcp   (+ static demo client served from ./public)

import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const SUPPORTED_VERSIONS = ["2025-11-25", "2025-06-18", "2025-03-26"];
const DATA_FILE = path.join(__dirname, "data", "state.json");
const SERVER_INFO = { name: "pantrypal-mcp", title: "PantryPal Kitchen Assistant", version: "1.0.0" };

// ---------------------------------------------------------------- state
const today = () => new Date().toISOString().slice(0, 10);
const addDays = (n) => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10);

function seed() {
  return {
    pantry: [
      { name: "eggs", quantity: 6, unit: "pcs", expires: addDays(5) },
      { name: "milk", quantity: 1, unit: "litre", expires: addDays(1) },
      { name: "onion", quantity: 4, unit: "pcs", expires: addDays(12) },
      { name: "tomato", quantity: 3, unit: "pcs", expires: addDays(2) },
      { name: "rice", quantity: 2, unit: "kg", expires: null },
    ],
    shopping: [],
  };
}

function load() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); } catch { return seed(); }
}
let state = load();
function save() {
  try {
    fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
    fs.writeFileSync(DATA_FILE, JSON.stringify(state, null, 2));
  } catch (e) { console.error("persist failed:", e.message); }
}
const norm = (s) => String(s).trim().toLowerCase();
const daysLeft = (iso) => (iso ? Math.ceil((new Date(iso) - new Date(today())) / 864e5) : null);

const RECIPES = [
  { name: "Masala Omelette", ingredients: ["eggs", "onion", "tomato", "green chilli"], minutes: 10 },
  { name: "Paneer Bhurji", ingredients: ["paneer", "onion", "tomato"], minutes: 20 },
  { name: "Veg Fried Rice", ingredients: ["rice", "carrot", "onion", "soy sauce"], minutes: 25 },
  { name: "Aloo Paratha", ingredients: ["wheat flour", "potato", "butter"], minutes: 30 },
  { name: "Tomato Pasta", ingredients: ["pasta", "tomato", "garlic", "olive oil"], minutes: 20 },
  { name: "Dal Tadka", ingredients: ["lentils", "onion", "tomato", "garlic"], minutes: 35 },
  { name: "Grilled Cheese Sandwich", ingredients: ["bread", "cheese", "butter"], minutes: 10 },
  { name: "Poha", ingredients: ["poha", "onion", "peanuts", "potato"], minutes: 15 },
];

// ---------------------------------------------------------------- tools
const str = { type: "string" };
const TOOLS = [
  {
    name: "add_pantry_item",
    title: "Add pantry item",
    description: "Add an ingredient to the pantry (or increase its quantity if it already exists).",
    inputSchema: {
      type: "object",
      properties: {
        name: { ...str, description: "Ingredient name, e.g. 'paneer'" },
        quantity: { type: "number", minimum: 0, description: "Amount, default 1" },
        unit: { ...str, description: "Unit, e.g. kg, litre, pcs" },
        expires_in_days: { type: "integer", minimum: 0, description: "Days until it expires" },
      },
      required: ["name"],
    },
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false },
    run(a) {
      const name = norm(a.name);
      const qty = a.quantity ?? 1;
      let item = state.pantry.find((i) => i.name === name);
      if (item) { item.quantity += qty; if (a.unit) item.unit = a.unit; }
      else { item = { name, quantity: qty, unit: a.unit || "pcs", expires: null }; state.pantry.push(item); }
      if (a.expires_in_days !== undefined) item.expires = addDays(a.expires_in_days);
      state.shopping = state.shopping.filter((s) => s.name !== name); // bought it
      save();
      return { text: `Added ${qty} ${item.unit} of ${name}. You now have ${item.quantity} ${item.unit}.`, data: { item } };
    },
  },
  {
    name: "list_pantry",
    title: "List pantry",
    description: "List everything currently in the pantry with quantities and days left before expiry.",
    inputSchema: { type: "object", properties: {} },
    annotations: { readOnlyHint: true },
    run() {
      const items = state.pantry.map((i) => ({ ...i, days_left: daysLeft(i.expires) }));
      const text = items.length
        ? "Your pantry has: " + items.map((i) => `${i.quantity} ${i.unit} ${i.name}`).join(", ") + "."
        : "Your pantry is empty.";
      return { text, data: { items } };
    },
  },
  {
    name: "remove_pantry_item",
    title: "Remove pantry item",
    description: "Use up or remove an ingredient. Omit quantity to remove it completely.",
    inputSchema: {
      type: "object",
      properties: { name: str, quantity: { type: "number", minimum: 0 } },
      required: ["name"],
    },
    annotations: { readOnlyHint: false, destructiveHint: true },
    run(a) {
      const name = norm(a.name);
      const item = state.pantry.find((i) => i.name === name);
      if (!item) return { error: `I couldn't find ${name} in your pantry.` };
      if (a.quantity !== undefined && a.quantity < item.quantity) {
        item.quantity -= a.quantity; save();
        return { text: `Used ${a.quantity} ${item.unit} of ${name}. ${item.quantity} ${item.unit} left.`, data: { item } };
      }
      state.pantry = state.pantry.filter((i) => i !== item); save();
      return { text: `Removed ${name} from your pantry.`, data: { removed: name } };
    },
  },
  {
    name: "check_expiring",
    title: "Check expiring items",
    description: "Find pantry items that expire within the next N days (default 3).",
    inputSchema: { type: "object", properties: { within_days: { type: "integer", minimum: 0, default: 3 } } },
    annotations: { readOnlyHint: true },
    run(a) {
      const n = a.within_days ?? 3;
      const items = state.pantry
        .filter((i) => i.expires && daysLeft(i.expires) <= n)
        .map((i) => ({ ...i, days_left: daysLeft(i.expires) }))
        .sort((x, y) => x.days_left - y.days_left);
      const text = items.length
        ? "Use these soon: " + items.map((i) => `${i.name} (${i.days_left <= 0 ? "expires today" : i.days_left + " day" + (i.days_left > 1 ? "s" : "")})`).join(", ") + "."
        : `Nothing expires in the next ${n} days.`;
      return { text, data: { items } };
    },
  },
  {
    name: "suggest_recipes",
    title: "Suggest recipes",
    description: "Suggest recipes that can be cooked from the pantry, fewest missing ingredients first.",
    inputSchema: { type: "object", properties: { max_results: { type: "integer", minimum: 1, maximum: 8, default: 3 } } },
    annotations: { readOnlyHint: true },
    run(a) {
      const have = new Set(state.pantry.map((i) => i.name));
      const expiring = new Set(state.pantry.filter((i) => i.expires && daysLeft(i.expires) <= 3).map((i) => i.name));
      const ranked = RECIPES.map((r) => {
        const missing = r.ingredients.filter((x) => !have.has(x));
        const uses_expiring = r.ingredients.filter((x) => expiring.has(x));
        return { name: r.name, minutes: r.minutes, missing, uses_expiring, matched: r.ingredients.length - missing.length };
      })
        .filter((r) => r.matched > 0)
        .sort((x, y) => x.missing.length - y.missing.length || y.uses_expiring.length - x.uses_expiring.length);
      const top = ranked.slice(0, a.max_results ?? 3);
      const text = top.length
        ? top.map((r) => r.missing.length ? `${r.name} (need ${r.missing.join(", ")})` : `${r.name} (you have everything)`).join("; ") + "."
        : "I couldn't find a recipe for what you have. Try adding more ingredients.";
      return { text: top.length ? "You could make: " + text : text, data: { recipes: top } };
    },
  },
  {
    name: "add_to_shopping_list",
    title: "Add to shopping list",
    description: "Add an item to the shopping list. Pass recipe to add all missing ingredients for a recipe.",
    inputSchema: {
      type: "object",
      properties: { name: { ...str, description: "Item to buy" }, recipe: { ...str, description: "Recipe name; adds its missing ingredients" } },
    },
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true },
    run(a) {
      let names = [];
      if (a.recipe) {
        const r = RECIPES.find((x) => norm(x.name) === norm(a.recipe));
        if (!r) return { error: `I don't know a recipe called ${a.recipe}.` };
        const have = new Set(state.pantry.map((i) => i.name));
        names = r.ingredients.filter((x) => !have.has(x));
      }
      if (a.name) names.push(norm(a.name));
      if (!names.length) return { error: "Tell me what to add, or give me a recipe you are missing ingredients for." };
      const added = [];
      for (const n of names) if (!state.shopping.some((s) => s.name === n)) { state.shopping.push({ name: n }); added.push(n); }
      save();
      return { text: added.length ? `Added ${added.join(", ")} to your shopping list.` : "Those are already on your list.", data: { added, shopping: state.shopping } };
    },
  },
  {
    name: "get_shopping_list",
    title: "Get shopping list",
    description: "Read back the current shopping list.",
    inputSchema: { type: "object", properties: {} },
    annotations: { readOnlyHint: true },
    run() {
      const text = state.shopping.length ? "Your shopping list: " + state.shopping.map((s) => s.name).join(", ") + "." : "Your shopping list is empty.";
      return { text, data: { shopping: state.shopping } };
    },
  },
];

// ---------------------------------------------------------------- JSON-RPC / MCP
const ok = (id, result) => ({ jsonrpc: "2.0", id, result });
const err = (id, code, message) => ({ jsonrpc: "2.0", id, error: { code, message } });

function validateArgs(schema, args) {
  const props = schema.properties || {};
  for (const k of schema.required || []) if (args[k] === undefined) return `Missing required argument: ${k}`;
  for (const [k, v] of Object.entries(args)) {
    const t = props[k]?.type;
    if (!t) continue;
    if (t === "string" && typeof v !== "string") return `Argument ${k} must be a string`;
    if ((t === "number" || t === "integer") && typeof v !== "number") return `Argument ${k} must be a number`;
    if (t === "integer" && !Number.isInteger(v)) return `Argument ${k} must be an integer`;
    if (props[k].minimum !== undefined && v < props[k].minimum) return `Argument ${k} must be >= ${props[k].minimum}`;
    if (props[k].maximum !== undefined && v > props[k].maximum) return `Argument ${k} must be <= ${props[k].maximum}`;
  }
  return null;
}

function handleRpc(msg, ctx) {
  const { id, method, params = {} } = msg;
  switch (method) {
    case "initialize": {
      const v = SUPPORTED_VERSIONS.includes(params.protocolVersion) ? params.protocolVersion : SUPPORTED_VERSIONS[0];
      ctx.newSession = randomUUID();
      return ok(id, {
        protocolVersion: v,
        capabilities: { tools: { listChanged: false } },
        serverInfo: SERVER_INFO,
        instructions: "PantryPal manages a household pantry and shopping list. Prefer suggest_recipes and check_expiring when the user asks what to cook.",
      });
    }
    case "ping": return ok(id, {});
    case "tools/list":
      return ok(id, { tools: TOOLS.map(({ run, ...t }) => t) });
    case "tools/call": {
      const tool = TOOLS.find((t) => t.name === params.name);
      if (!tool) return err(id, -32602, `Unknown tool: ${params.name}`);
      const args = params.arguments ?? {};
      if (typeof args !== "object" || Array.isArray(args)) return err(id, -32602, "arguments must be an object");
      const bad = validateArgs(tool.inputSchema, args);
      if (bad) return err(id, -32602, bad);
      try {
        const r = tool.run(args);
        if (r.error) return ok(id, { content: [{ type: "text", text: r.error }], isError: true });
        return ok(id, { content: [{ type: "text", text: r.text }], structuredContent: r.data });
      } catch (e) {
        return ok(id, { content: [{ type: "text", text: `Tool failed: ${e.message}` }], isError: true });
      }
    }
    default:
      return err(id, -32601, `Method not found: ${method}`);
  }
}

// ---------------------------------------------------------------- HTTP
const sessions = new Set();
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".json": "application/json" };

function originAllowed(req) {
  const origin = req.headers.origin;
  if (!origin) return true; // non-browser clients
  try {
    const o = new URL(origin);
    if (o.host === req.headers.host) return true;
    if (["localhost", "127.0.0.1", "[::1]"].includes(o.hostname)) return true;
    return (process.env.ALLOWED_ORIGINS || "").split(",").map((s) => s.trim()).includes(origin);
  } catch { return false; }
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (c) => { data += c; if (data.length > 1e6) { reject(new Error("too large")); req.destroy(); } });
    req.on("end", () => resolve(data));
    req.on("error", reject);
  });
}

async function handleMcp(req, res) {
  if (!originAllowed(req)) { res.writeHead(403).end("Forbidden origin"); return; }
  if (req.method === "GET") { res.writeHead(405, { Allow: "POST, DELETE" }).end(); return; } // no server-initiated stream
  if (req.method === "DELETE") {
    sessions.delete(req.headers["mcp-session-id"]);
    res.writeHead(200).end(); return;
  }
  if (req.method !== "POST") { res.writeHead(405, { Allow: "POST, DELETE" }).end(); return; }

  let body;
  try { body = JSON.parse(await readBody(req)); }
  catch { res.writeHead(400, { "Content-Type": "application/json" }).end(JSON.stringify(err(null, -32700, "Parse error"))); return; }

  const msgs = Array.isArray(body) ? body : [body];
  const sid = req.headers["mcp-session-id"];
  const isInit = msgs.some((m) => m.method === "initialize");
  if (!isInit && sid !== undefined && !sessions.has(sid)) { res.writeHead(404).end(); return; } // expired/unknown session

  const ctx = {};
  const out = [];
  for (const m of msgs) {
    if (!m || m.jsonrpc !== "2.0") { out.push(err(m?.id ?? null, -32600, "Invalid Request")); continue; }
    if (m.method === undefined) continue; // a client response — nothing to do
    if (m.id === undefined) continue;     // notification — no reply
    out.push(handleRpc(m, ctx));
  }
  const headers = { "Content-Type": "application/json", "Cache-Control": "no-store" };
  if (ctx.newSession) { sessions.add(ctx.newSession); headers["Mcp-Session-Id"] = ctx.newSession; }
  if (!out.length) { res.writeHead(202).end(); return; } // only notifications/responses
  res.writeHead(200, headers).end(JSON.stringify(Array.isArray(body) ? out : out[0]));
}

function serveStatic(req, res) {
  const url = new URL(req.url, "http://x");
  let p = path.normalize(decodeURIComponent(url.pathname)).replace(/^(\.\.[/\\])+/, "");
  if (p === "/" || p === "\\") p = "/index.html";
  const file = path.join(__dirname, "public", p);
  if (!file.startsWith(path.join(__dirname, "public"))) { res.writeHead(403).end(); return; }
  fs.readFile(file, (e, buf) => {
    if (e) { res.writeHead(404).end("Not found"); return; }
    res.writeHead(200, { "Content-Type": MIME[path.extname(file)] || "application/octet-stream" }).end(buf);
  });
}

http.createServer((req, res) => {
  const pathname = req.url.split("?")[0];
  if (pathname === "/mcp") handleMcp(req, res).catch((e) => { console.error(e); res.writeHead(500).end(); });
  else if (pathname === "/health") res.writeHead(200, { "Content-Type": "application/json" }).end('{"ok":true}');
  else if (req.method === "GET") serveStatic(req, res);
  else res.writeHead(404).end();
}).listen(PORT, () => {
  console.log(`PantryPal MCP server  → http://localhost:${PORT}/mcp`);
  console.log(`Simulated Alexa+ demo → http://localhost:${PORT}/`);
});
